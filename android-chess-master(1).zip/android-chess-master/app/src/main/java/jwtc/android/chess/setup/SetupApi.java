package jwtc.android.chess.setup;

import jwtc.android.chess.services.GameApi;

public class SetupApi extends GameApi {}
