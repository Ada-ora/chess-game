package jwtc.android.chess.puzzle;

import jwtc.android.chess.services.GameApi;

public class PuzzleApi extends GameApi {}
