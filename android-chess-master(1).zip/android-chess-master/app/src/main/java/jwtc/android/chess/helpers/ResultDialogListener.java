package jwtc.android.chess.helpers;

import android.os.Bundle;

public interface ResultDialogListener {

    public void OnDialogResult(int requestCode, Bundle data);
}
